<?php

namespace SilkSoftware\Hockeyteam\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\DB\Adapter\AdapterInterface;

class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        if (version_compare($context->getVersion(), '1.0.5') < 0){

		$installer->run('DROP TABLE IF EXISTS `hockey_team`');
$installer->run('CREATE TABLE `hockey_team` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT \'\',
  `number` int(10) NOT NULL DEFAULT \'0\',
  `status` enum(\'2\',\'1\') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8');
$installer->run('-- ----------------------------
-- Records of hockey_team
-- ----------------------------
INSERT INTO `hockey_team` VALUES (\'1\', \'aaa\', \'111\', \'1\')');
$installer->run('INSERT INTO `hockey_team` VALUES (\'2\', \'eee\', \'222\', \'1\')');


		//demo 
//$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
//$scopeConfig = $objectManager->create('Magento\Framework\App\Config\ScopeConfigInterface');
//demo 

		}

        $installer->endSetup();

    }
}